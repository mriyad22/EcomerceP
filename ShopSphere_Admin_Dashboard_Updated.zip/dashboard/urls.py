from django.urls import path
from . import views

app_name = 'dashboard'
urlpatterns = [
    path('dashboard/', views.dashboard, name='dashboard'),
    path('dashboard/products/', views.product_list, name='products'),
    path('dashboard/products/add/', views.product_form, name='product_add'),
    path('dashboard/products/<int:pk>/edit/', views.product_form, name='product_edit'),
    path('dashboard/products/<int:pk>/delete/', views.product_delete, name='product_delete'),
    path('dashboard/categories/', views.categories, name='categories'),
    path('dashboard/categories/<int:pk>/edit/', views.category_edit, name='categories_edit'),
    path('dashboard/categories/<int:pk>/delete/', views.category_delete, name='categories_delete'),
    path('dashboard/brands/', views.brands, name='brands'),
    path('dashboard/brands/<int:pk>/edit/', views.brand_edit, name='brands_edit'),
    path('dashboard/brands/<int:pk>/delete/', views.brand_delete, name='brands_delete'),
    path('dashboard/coupons/', views.coupons, name='coupons'),
    path('dashboard/coupons/<int:pk>/delete/', views.coupon_delete, name='coupon_delete'),
    path('dashboard/orders/', views.order_list, name='orders'),
    path('dashboard/orders/<str:order_number>/', views.order_detail, name='order_detail'),
]
